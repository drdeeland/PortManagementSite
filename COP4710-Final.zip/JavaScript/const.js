var CONSTANT = function() {
    let urlBase = 'http://localhost/dbproj/php';
    let extension = '.php';

    return {
        urlBase,
        extension
    };
}();